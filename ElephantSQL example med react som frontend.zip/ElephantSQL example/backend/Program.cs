using Microsoft.EntityFrameworkCore;

//Denne klasse svarer til server.ts fra vores Typescript udgave.

var builder = WebApplication.CreateBuilder(args);

var MyAllowSpecificOrigins = "_myAllowSpecificOrigins";

//Benytter sig af connection string fra appsettings.json
var configuration = new ConfigurationBuilder()
    .SetBasePath(builder.Environment.ContentRootPath)
    .AddJsonFile("appsettings.json")
    .Build();

//Tilf�jer de forskellige controller vi har
builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
//Giver swagger indstillingerne.
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//Tilf�jer databasen som del af programmet ved opstart.
builder.Services.AddDbContext<MyDbContext>().AddMvc();

builder.Services.AddCors(options =>
{
    options.AddPolicy(name: MyAllowSpecificOrigins,
                      policy  =>
                      {
                          policy.WithOrigins("http://localhost:3000").AllowAnyHeader().AllowAnyMethod();
                      });
});

var app = builder.Build();

// G�r at appen benytter sig af Swagger, hvis vi milj�et er udvikling.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors(MyAllowSpecificOrigins);

app.UseHttpsRedirection();

app.UseAuthorization();

//Appen benytter sig nu af controllers
app.MapControllers();

app.Run();
