import React from "react";

//const AuthContext = React.createContext(false);
const AuthContext = React.createContext({});

export default AuthContext;