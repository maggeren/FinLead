import React, { useEffect, useState } from "react";
//import "../../../styles/navbar.css";


function About() {
   
    const[users, setUsers] = useState([]);

    const fetchUsers = async() =>{
        try{
            const response = await fetch(`http://localhost:7050/Person/person`,
            {
                         method: "GET",
                         headers: {
                           "Content-Type": "application/json",
                         },
                         cache: "default",
                       }
            );
            const responseData = await response.json();
            console.log(responseData);
            setUsers(responseData)

        }
        catch(error){
            console.log(error);
        }
    }

    useEffect(()=>{
        fetchUsers();
    }, [])

    return (
        <div style={{backgroundColor: "white"}}>
               {users.map((user, index)=>(
                 <div key={index}>
                    <p>{user.firstName}</p>
                    <p>{user.lastName}</p>
                    <p>{user.country}</p>
                 </div>   
               ))}
        </div>
    )
}

export default About;