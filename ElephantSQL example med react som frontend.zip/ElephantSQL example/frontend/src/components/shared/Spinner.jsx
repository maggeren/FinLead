import "../../index.css";

export function Spinner() {
  return (
    <div className="spinner-border">
      <span className="sr-only">Loading...</span>
    </div>
  );
}
